package com.pixo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;
import com.pixo.bean.AccountDetails;
import com.pixo.bean.Followers;
import com.pixo.dao.UserDAO;

@Service("UserService")
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	public UserDAO userDAO;
	
	public UserServiceImpl(){
		
	}
	
	public boolean registerUser(AccountDetails user) {
		return userDAO.registerUser(user);
	}

	public boolean authenticate(String email, String password) {
		return userDAO.authenticate(email, password);
	}

	public AccountDetails getUser(String email) {
		return userDAO.getUser(email);
	}

	public boolean uploadProfilePicture(ProfilePicture pic) {
		return userDAO.uploadProfilePicture(pic);
	}

	public boolean addComment(UserComments cmt) {
		return userDAO.addComment(cmt);
	}

	public List<UserComments> showComments(int picId) {
		return userDAO.showComments(picId);
	}

	public boolean updateUser(int id, String userName, String lastname,String password, String emailID) {
		return userDAO.updateUser(id, userName,lastname, password, emailID);
	}

	public List<AccountDetails> getUsers(String name) {		
		return userDAO.getUsers(name);
	}

	public AccountDetails getUserDetails(int id) {
		return userDAO.getUserDetails(id);
	}

	public boolean Follow(Followers followers) {		
		return userDAO.Follow(followers);
	}

	public boolean unFollow(int followerId, int followingId) {
		return userDAO.unFollow(followerId, followingId);	
	}

	public List<Followers> myFollowers(int myId) {		
		return userDAO.myFollowers(myId);
	}

	public List<Followers> meFollowing(int myId) {
		return userDAO.meFollowing(myId);
	}

	public boolean userExistence(String email) {
		return userDAO.userExistence(email);
	}

	public boolean checkFollow(int followerId, int followingId) {		
		return userDAO.checkFollow(followerId, followingId);
	}

}
